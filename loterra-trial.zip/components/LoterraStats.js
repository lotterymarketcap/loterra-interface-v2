
import styles from '../styles/components/LoterraStats.module.scss'
import { Ticket, Users } from "phosphor-react";

export default function LoterraStats(){
    return(
        <div className="lota-card">
            <div className={styles.stats}>
                <h2 className="center">Some title</h2>
            </div>
        </div>
    )
}